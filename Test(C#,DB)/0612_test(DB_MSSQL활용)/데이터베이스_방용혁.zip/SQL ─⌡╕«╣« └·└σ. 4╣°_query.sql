SELECT r.idx AS �뿩��ȣ,
       m.Names AS �뿩ȸ��,
       d.Names AS �帣,
       b.Names AS �뿩å����,
       b.ISBN ,
       r.rentalDate AS �뿩��

   FROM bookstbl AS b
      INNER JOIN rentaltbl AS r
         ON b.idx=r.bookIdx
      INNER JOIN Divtbl AS d
         ON b.Division = d.Division
      INNER JOIN membertbl AS m
         ON m.idx=r.idx

   ORDER BY r.rentalDate ASC;