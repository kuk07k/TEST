SELECT divtbl.Names AS '�帣', 
	   bookstbl.Author AS '�۰�', 
	   bookstbl.Names AS 'å����'
FROM divtbl
INNER JOIN bookstbl
ON divtbl.Division = bookstbl.Division
ORDER BY divtbl.Names DESC, bookstbl.Author ASC;
